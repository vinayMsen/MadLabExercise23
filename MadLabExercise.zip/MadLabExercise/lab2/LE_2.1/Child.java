class Child extends Mother{

}