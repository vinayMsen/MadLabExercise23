public class Main
{
	public static void main(String[] args) {
		Mother m=new Mother();
		m.show();
		Child chd=new Child();
		chd.show();
	}
}
