class ducks {
    void  swim(){
        System.out.println("all know of swimming method ");
    }
}