class duryodhan extends kauravs{
   public void obedience(){
        System.out.print("Obedience 0%\n");
    }
    public void kindness(){
        System.out.print("Kindness 0%\n");
    }}