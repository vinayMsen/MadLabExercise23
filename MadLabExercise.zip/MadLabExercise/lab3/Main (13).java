
public class Main
{
	public static void main(String[] args) {
	 RD q=new RD();
	    
		q.swim();
		q.quack();
		
		
	WD w=new WD();
	w.swim();
	
	RHD rh=new RHD();
	
	rh.swim();
	rh.fly();
	rh.quack();
	
	LD l=new LD();
		l.swim();
	    l.fly();
	    l.quack();
	
	
		

	}
}
