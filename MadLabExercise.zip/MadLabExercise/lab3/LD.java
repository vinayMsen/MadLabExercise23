class LD extends ducks implements quackable,flyable{
   public  void fly(){
        System.out.println("ld fly"); 
    }

   public  void quack(){
         System.out.println("ld quack");
         
         
    }
}