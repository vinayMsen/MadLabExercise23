interface flyable{
    void fly();
}