abstract class kauravs extends bharatvanshi{
   
     abstract public void obedience();
    abstract public void kindness();
   
   
}