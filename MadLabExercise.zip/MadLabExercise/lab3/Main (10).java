/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		arjun a = new arjun();
		a.fighter();
		a.obedience();
		a.kindness();
		
		System.out.print("\n\n");
		
		bheem b = new bheem();
		b.fighter();
		b.obedience();
		b.kindness();
		
		System.out.print("\n\n");
		
		duryodhan d = new duryodhan();
		d.fighter();
		d.obedience();
		d.kindness();
		
		System.out.print("\n\n");
		
		vikarn v = new vikarn();
		v.fighter();
		v.obedience();
		v.kindness();
		
		System.out.print("\n\n");
	}
}
