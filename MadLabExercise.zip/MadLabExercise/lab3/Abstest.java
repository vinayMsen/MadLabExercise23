abstract class Abstest implements Testable{
    public abstract void display();
}