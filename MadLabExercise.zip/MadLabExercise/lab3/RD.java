class RD extends ducks  implements quackable{
  
 
   public  void quack(){
         System.out.println("rd squeaks");
         
         
    }
}