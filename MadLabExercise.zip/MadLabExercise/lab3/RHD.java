class RHD extends ducks implements quackable,flyable{
    public void fly(){
        System.out.println("rhd fly"); 
    }

    public void quack(){
         System.out.println("rhd quack");
         
         
    }
}