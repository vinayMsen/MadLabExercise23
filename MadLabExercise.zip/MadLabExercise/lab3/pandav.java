abstract class pandav extends bharatvanshi{
        public void obedience(){
        System.out.print("Obedience 100%\n");
    }
    abstract public void kindness();
}