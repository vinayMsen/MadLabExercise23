class bharatvanshi{
    void fighter(){
        System.out.println("fighter 100%\n");
    }
    
}