class WD extends ducks{
  
}