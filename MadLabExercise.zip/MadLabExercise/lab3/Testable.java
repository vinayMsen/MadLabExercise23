interface Testable {
    void display();
    
}