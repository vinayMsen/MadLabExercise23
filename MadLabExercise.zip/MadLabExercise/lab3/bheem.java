class bheem extends pandav{
     public void kindness(){
        System.out.print("Kindness 70%\n");
    }
   
}