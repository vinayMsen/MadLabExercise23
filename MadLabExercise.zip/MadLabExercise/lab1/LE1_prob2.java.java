/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("Printing pyramid");
		int i,j,N
		for(i=1;i<10;i++)
		{
		    for(j=10;j>i;j--)
		    {
		        System.out.print(" ");
		    }
		    N=0;
		   while(N<i)
		   {
		       System.out.print("* ");
		       N++;
		   }
		   System.out.print("\n");
		}
		System.out.println("Printing inverted pyramid");
		for( i=1;i<6;i++)
		{
		    for( j=6;j>i;j--)
		    {
		        System.out.print("* ");
		    }
		     N=0;
		    System.out.println("\n");
		   while(N<i)
		   {
		       System.out.print(" ");
		       N++;
		   }
		   //System.out.print("\n");
		}
		
	}
}
